function App() {
  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "#0f172a",
      fontFamily: "system-ui, sans-serif",
      color: "#f1f5f9"
    }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>🤖</div>
        <h1 style={{ fontSize: 32, fontWeight: 700, margin: "0 0 8px" }}>
          BAS Bot Assistant
        </h1>
        <p style={{ color: "#94a3b8", fontSize: 16, margin: "0 0 24px" }}>
          AI-ассистент по BrowserAutomationStudio работает
        </p>
        <div style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 8,
          background: "#1e293b",
          borderRadius: 999,
          padding: "8px 20px",
          fontSize: 14
        }}>
          <span style={{
            width: 8, height: 8, borderRadius: "50%",
            background: "#22c55e", display: "inline-block"
          }} />
          Онлайн
        </div>
      </div>
    </div>
  );
}

export default App;
